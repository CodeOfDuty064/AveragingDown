import React from "react";

export default function Graph() {
  // 사용자 평단 Before & After Graph Component
  return (
    <>
      <div>Graph Componenet</div>
    </>
  );
}
