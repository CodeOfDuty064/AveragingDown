import React from "react";

export default function Chart() {
  // 메이저 코인 실시간 가격 차트 Component
  return (
    <>
      <div>Chart Componenet</div>
    </>
  );
}
