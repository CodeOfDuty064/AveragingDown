import React from "react";

export default function Share() {
  // SNS 공유하기 Component
  return (
    <>
      <div>Share Componenet</div>
    </>
  );
}
