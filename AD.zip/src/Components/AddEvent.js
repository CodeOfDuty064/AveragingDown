import React from "react";

export default function Modal() {
  // 종목 추가 Modal Component
  return (
    <>
      <div>AddEvent Componenet</div>
    </>
  );
}
