// Components
// import Header from "../Common/Header";
// import Footer from "../Common/Footer";
// import Modal from "../Common/Modal";

// Images
import wonyong from "../../assets/img/profile_jang";
import areum from "../../assets/img/profile_shin";

export { wonyong, areum };
